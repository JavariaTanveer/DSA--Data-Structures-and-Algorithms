//L1F20BSSE0015
//JAVARIA TANVEER
#include<iostream>
#include<string>
using namespace std;
class Sectioninfo
{
private:
	string sectionname;
	string Coursename;
	string CourseInstructorName;
	int StudentStrength;
public:
	Sectioninfo()
	{
		sectionname = " "; 
		Coursename = " "; 
		CourseInstructorName = " "; 
		StudentStrength = 0;
	}
	Sectioninfo(string sectionname, string Coursename, string CourseInstructorName, int StudentStrength)
	{
		this->sectionname = sectionname;
		this->Coursename = Coursename;
		this->CourseInstructorName = CourseInstructorName;
		this->StudentStrength = StudentStrength;
	}
	void setsectionname(string sectionname)
	{
		this->sectionname = sectionname;
	}
	void setCoursename(string Coursename)
	{
		this->Coursename = Coursename;
	}
	void setCourseInstructorName(string CourseInstructorName)
	{
		this->CourseInstructorName = CourseInstructorName;
	}
	void setStudentStrength(int StudentStrength)
	{
		this->StudentStrength =StudentStrength;
	}
	string  getsectionname()
	{
		return sectionname;
	}
	string getCoursename()
	{
		return Coursename;
	}
	string  getCourseInstructorName()
	{
		return CourseInstructorName;
	}
	int getStudentStrength()
	{
		return StudentStrength;
	}
};
class TreeNode
{
private:
	Sectioninfo obj;
	TreeNode* left;
	TreeNode* right;
public:
	TreeNode()
	{
		left = NULL;
		right = NULL;
	}
	void setinfo(string sectionname, string Coursename, string CourseInstructorName, int StudentStrength)
	{
		obj.setsectionname(sectionname);
		obj.setCoursename(Coursename);
		obj.setCourseInstructorName(CourseInstructorName);
		obj.setStudentStrength(StudentStrength);
	}
	string getinfo()
	{
		return "Section: " + obj.getsectionname() + ", Course name : " + obj.getCoursename() + ", Course Instructor name : " + obj.getCourseInstructorName() + ", Student Strength : " + to_string(obj.getStudentStrength()) + " ";
	}
	int getStudentStrengthT()
	{
		return obj.getStudentStrength();
	}
	void setleft(TreeNode* left)
	{
		this->left = left;
	}
	TreeNode* getleft()
	{
		return left;
	}
	void setrigth(TreeNode* right)
	{
		this->right = right;
	}
	TreeNode* getrigth()
	{
		return right;
	}
	bool isleaf(TreeNode* Node)
	{
		//Leaf node
		if (Node->right == NULL && Node->left == NULL)
			return true;
		else
			return false;
	}
};
TreeNode* inputdata()
{
	string sectionname = " ";
	string coursename = " ";
	string CourseInstructorName = " ";
	int StudentStrength = 0;

	cout << "\nEnter Section: ";
	cin >> sectionname;
	cout << "\nEnter Course name: ";
	cin >> coursename;
	cout << "\nEnter Course instructor name: ";
	cin >> CourseInstructorName;
	cout << "\nEnter StudentStrength: ";
	cin >> StudentStrength;

	TreeNode* temp = new TreeNode;
	temp->setinfo(sectionname, coursename, CourseInstructorName, StudentStrength);
	return temp;
}
TreeNode* addNode()
{
	//add node is basically to input the data
	TreeNode* temp = inputdata();
	return temp;
}
class BST
{
private:
	TreeNode* root;
	int size;
public:
	BST()
	{
		root = NULL;
		size = 0;
	}
	void insert()
	{
		TreeNode* temp = addNode();
		if (root == NULL)
			root = temp;
		else
		{
			TreeNode* temp1 = root;
			while (true)
			{
				if (temp1->getStudentStrengthT() > temp1->getStudentStrengthT())
				{
					if (temp1->getleft() == NULL)
					{
						temp1->setleft(temp1);
						break;
					}
					else
						temp = temp->getleft();
				}
				else
				{
					if (temp->getrigth() == NULL)
					{
						temp->setrigth(temp1);
						break;
					}
					else
						temp = temp->getrigth();
				}
			}
		}
	}
	TreeNode* getroot()
	{
		return root;
	}
	bool isEmpty(TreeNode* temp)
	{
		if (temp != NULL)
			return true;
		else
			return false;
	}
	TreeNode* deletenode(int data, TreeNode* root)
	{
		if (root == NULL)
			cout << "Tree is empty " << endl;
		else
		{
			TreeNode* prev = NULL;
			TreeNode* temp = root;
			bool flag;
			while (temp != NULL)
			{
				if (data > temp->getStudentStrengthT())
				{
					prev = temp;
					temp = temp->getrigth();
					flag = true;
				}
				else if (data < temp->getStudentStrengthT())
				{
					prev = temp;
					temp = temp->getleft();
					flag = false;
				}
				else
				{
					if (temp->isleaf(temp))
					{
						delete temp;
					}
					else if (temp->getleft() != NULL && temp->getrigth() != NULL)
					{
						prev->setleft(temp->getleft());
						prev->setrigth(temp->getrigth());
						delete temp;
					}
					else
					{
						if (flag==true)
						{
							if (temp->getrigth() != NULL)
								prev->setrigth(temp->getrigth());
							else
								prev->setrigth(temp->getleft());
						}
						else
						{
							if (temp->getleft() != NULL)
								prev->setleft(temp->getleft());
							else
								prev->setleft(temp->getrigth());
						}
						delete temp;
						break;

					}
				}
			}
			return prev;
		}
	}
void inorder(TreeNode* temp)
	{
		if (temp == NULL)
			return;
		else
		{
			inorder(temp->getleft());
			cout << temp->getStudentStrengthT() << " ";
			inorder(temp->getrigth());
		}
	}
void preorder(TreeNode* temp)
	{
		if (temp == NULL)
			return;
		else
		{
			cout << temp->getStudentStrengthT() << endl;
			preorder(temp->getleft());
			preorder(temp->getrigth());
		}
	}
void postorder(TreeNode* temp)
	{
		if (temp == NULL)
			return;
		else
		{
			postorder(temp->getleft());
			postorder(temp->getrigth());
			cout << temp->getStudentStrengthT() << " ";
		}
	}
//searching using strength of students
TreeNode* search(int data)
	{
		if (root == NULL)
			return NULL;
		else
		{
			TreeNode* temp = root;
			while (temp != NULL)
			{
				if (temp->getStudentStrengthT() == data)
				{
					cout << temp->getinfo() << endl;
					return temp;
				}
				else if (temp->getStudentStrengthT() < data)
					temp = temp->getrigth();
				else
					temp = temp->getleft();
			}
			return temp;
		}
	}
};
void preorder(TreeNode* temp)
{
	TreeNode* tem = temp;
	if (temp == NULL)
	{
		return;
	}
	else
	{
		cout << temp->getinfo() << endl;
		preorder(temp->getleft());
		preorder(temp->getrigth());
	}
}
void postorder(TreeNode* temp)
{
	TreeNode* tem = temp;
	if (tem == NULL)
	return;
	else
	{
		postorder(tem->getleft());
		postorder(tem->getrigth());
		cout << tem->getinfo() << endl;
	}
}
void populateTree()
{
	BST bst;
	TreeNode* temp = NULL;
	while(1)
	{
		cout << endl;
		cout << " Enter 1 to insert Data " << endl;
		cout << " Enter 2 for deletion of data " << endl;
		cout << " Enter 3 to Display StudentStrength in Inorder : " << endl;
		cout << " Enter 4 to Display StudentStrength in preorder :  " << endl;
		cout << " Enter 5 to Display StudentStrength in postorder : " << endl;
		cout << " If you want to search press 6: " << endl;
		cout << " If you want to exit press 7: " << endl;
		int input;
		cout << " Enter the input :  ";
		cin >> input;
		cout << endl;
		if (input == 1)
		{
			bst.insert();
			temp = bst.getroot();
		}
		else if (input == 2)
		{
			cout << "Enter Student Strength of class: ";
			int StudentStrength = 0;
			cin >> StudentStrength;
			TreeNode* temp1 = bst.deletenode(StudentStrength, temp);
			temp = temp1;
		}
		else if (input == 3)
		{
			cout << "Inorder: ----strength of students" << endl;
			bst.inorder(temp);
		}
		else if (input == 4)
		{
			cout << "Pre order Traversal : ";
			preorder(temp);
			cout << endl;
		}
		else if (input == 5)
		{
			cout << "Post order Traversal : ";
				postorder(temp);
				cout << endl;
		}
		else if (input == 6)
		{
			cout << "Enter Student Strength of class for searching: ";
			int StudentStrength = 0;
			cin >> StudentStrength;
			bst.search(StudentStrength);
		}
		else if (input == 7)
		{
			cout << "Program ended successfully " << endl;
			exit(0);
		}
		else {
			cout << "Invalid Input " << endl;
			exit(0);
		}
	}


}
int main()
{
	populateTree();
}