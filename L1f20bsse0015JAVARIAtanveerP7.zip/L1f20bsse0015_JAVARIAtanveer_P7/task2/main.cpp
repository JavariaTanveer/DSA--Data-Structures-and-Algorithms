#include"ArrayList.cpp"
#include<string>
int main()
{
    string str;
    cout<<"Enter String: ";
    cin>>str;
    ArrayList <char> s(20);
    for(int i=0; i<str.length(); i++)
    {
        if(str[i]=='(' || str[i]=='{' || str[i]=='[')
        {
            s.push(str[i]);
            continue;
        }
        if(s.isEmpty())
        {
            s.push(str[i]);
            break;
        }
        char temp = s.top();
        if(str[i]=='}')
        {
            if(temp=='(' || temp=='[')
                break;
            s.pop();
        }
        else if(str[i]==']')
        {
            if(temp=='(' || temp=='{')
                break;
            s.pop();
        }
        else if(str[i]==')')
        {
            if(temp=='{' || temp=='[')
                break;
            s.pop();
        }
    }
    if(s.isEmpty())
    {
    cout<<"Correct Sequence"<<endl;
    }
    else{
    cout<<"Wrong Sequence"<<endl;
    }
//    (s.isEmpty())?cout<<"correct"<<endl:cout<<"incorrect"<<endl;

    return 0;
}