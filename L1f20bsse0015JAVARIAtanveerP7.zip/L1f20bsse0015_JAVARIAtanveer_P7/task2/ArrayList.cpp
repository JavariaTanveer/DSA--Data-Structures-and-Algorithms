#include "ArrayList.h"
template<class T>
ArrayList<T>::ArrayList(int size)
{
    this->size = size;
    arr = new T[size];
    current = -1;
    if (arr == NULL)
    {
        cout << "Memory not allocated";
        exit(0);
    }
}
template<class T>
ArrayList<T>::~ArrayList()
{
    if (arr != nullptr)
        delete[] arr;
}
template<class T>
bool ArrayList<T>::isFull()
{
    if ((current == size - 1) || (current + 1 == size))
        return true;
    return false;
}
template<class T>
bool ArrayList<T>::isEmpty()
{
    if (current == -1)
        return true;
    return false;
}
template<class T>
T ArrayList<T>::pop()
{
    if (!isEmpty())
    {
        int temp;
        temp = arr[current];
        current--;
        return temp;
    }
    else
        cerr << "ArrayList is Empty" << endl;
}
template<class T>
void ArrayList<T>::push(T data)
{
    if (!isFull())
    {
        current++;
        arr[current] = data;
    }
    else
        cerr << "ArrayList is full" << endl;
}
template<class T>
T ArrayList<T>::top()
{
    return arr[current];
}
template<class T>
void ArrayList<T>::display()
{
    for (int i = 0; i <= current; i++)
    {
        cout << arr[i] << "  ";
    }
}

