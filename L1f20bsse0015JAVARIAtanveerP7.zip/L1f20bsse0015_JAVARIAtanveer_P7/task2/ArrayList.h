#include<iostream>
#include<string>
using namespace std;
template<class T>
class ArrayList
{
private:

    T*arr;
    int size;
    T current;
public:
ArrayList(int);
~ArrayList();

//ArrayList operations
bool isEmpty();
bool isFull();
void push(T data);
T pop();
T top();

//Display
void display();

};