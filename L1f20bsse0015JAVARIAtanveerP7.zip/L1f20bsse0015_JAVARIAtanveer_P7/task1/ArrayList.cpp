#include "ArrayList.h"
ArrayList::ArrayList(int size)
{
    this->size = size;
    arr = new int[size];
    current = -1;
    if (arr == NULL)
    {
        cout << "Memory not allocated";
        exit(0);
    }
}
ArrayList::~ArrayList()
{
    if (arr != nullptr)
        delete[] arr;
}
bool ArrayList::isFull()
{
    if ((current == size - 1) || (current + 1 == size))
        return true;
    return false;
}
bool ArrayList::isEmpty()
{
    if (current == -1)
        return true;
    return false;
}
int ArrayList::pop()
{
    if (!isEmpty())
    {
        int temp;
        temp = arr[current];
        current--;
        return temp;
    }
    else
        cerr << "ArrayList is Empty" << endl;
}
void ArrayList::push(int data)
{
    if (!isFull())
    {
        current++;
        arr[current] = data;
    }
    else
        cerr << "ArrayList is full" << endl;
}
int ArrayList::top()
{
    return arr[current];
}
void ArrayList::display()
{
    for (int i = 0; i <= current; i++)
    {
        cout << arr[i] << "  ";
    }
}