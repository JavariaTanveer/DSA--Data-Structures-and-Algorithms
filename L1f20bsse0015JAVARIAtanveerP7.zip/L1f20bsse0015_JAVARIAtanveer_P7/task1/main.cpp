#include"ArrayList.cpp"
int main()
{
    ArrayList s(8);
    s.push(4);
    s.push(2);
    s.push(11);
    s.display();
    cout<<endl;

    s.push(77);
    s.pop();
    s.pop();
    s.push(78);
    s.push(989);
    s.display();
    cout<<endl;
    s.pop();
    s.pop();
    s.push(2222);
    s.push(44543);
    s.display();  
    s.pop(); 
    cout<<endl;
    cout<<"value at top is "<<s.top();
}