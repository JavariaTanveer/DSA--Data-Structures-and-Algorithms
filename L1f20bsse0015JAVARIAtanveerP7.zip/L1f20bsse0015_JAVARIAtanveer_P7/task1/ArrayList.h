#include<iostream>
using namespace std;
class ArrayList
{
private:
    int*arr;
    int size;
    int current;
public:
ArrayList(int);
~ArrayList();

//ArrayList operations
bool isEmpty();
bool isFull();
void push(int data);
int pop();
int top();

//Display
void display();

};