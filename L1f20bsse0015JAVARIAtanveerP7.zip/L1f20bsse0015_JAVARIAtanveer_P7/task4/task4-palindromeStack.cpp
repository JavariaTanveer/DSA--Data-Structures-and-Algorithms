#include <iostream>
using namespace std;
template <class T>
class stack
{
private:
    T *arr;
    int size;
    int current;

public:
    stack(int size)
    {
        this->size = size;
        arr = new T[size];
        current = -1;
    }
    bool isfull()
    {
        if (current == size - 1)
            return true;
        else
            return false;
    }
    bool isempty()
    {
        if (current == -1)
            return true;
        else
            return false;
    }
    void push(T value)
    {
        if (isfull())
            cout << "\n stack full";

        else
        {
            current++;
            arr[current] = value;
        }
    }
    T pop()
    {
        if (isempty())
            cout << "Stack empty";
        else
        {
            T temp = arr[current];
            arr[current] = 0;
            current--;
            return temp;
        }
    }
    void display()
    {
        // reversed
        for (int i = size - 1; i >= 0; i--)
        {
            cout << arr[i] << " ";
        }
    }
};
int main()
{
    char str[50];
    cout << "enter string : ";
    cin >> str;
    int c = 0;
    for (int i = 0; str[i] != '\0'; i++)
    {
        c++;
    }
    stack<char> p(c);
    for (int i = 0; i < c; i++)
    {
        p.push(str[i]);
    }
    bool issame;
    for (int i = 0, j = c - 1; i < c; i++, j--)
    {
        if (str[i] == str[j])
        {
            issame = true;
        }
        else
        {
            issame = false;
            break;
        }
    }
    if (issame)
    {
        cout << "Its a palindrome\n";
    }
    else
    {
        cout << "Its not a palindrome\n";
    }
    p.display();
}
