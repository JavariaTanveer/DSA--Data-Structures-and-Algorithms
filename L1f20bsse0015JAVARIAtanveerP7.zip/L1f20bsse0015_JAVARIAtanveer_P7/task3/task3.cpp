#include"MyStack.cpp"

int main()
{
		MyStack<char> obj(100);
		char infix[100];
		cout << " Enter the Infix Expression (Limit 100):";
		cin.getline(infix, 100);
		int size = 0, j = 0;
		for (int i = 0; infix[i] != '\0'; i++)
		{
			size++;
		}
		char* postfix = new char[size];
		for (int i = 0; i < size; i++)
		{
			if (infix[i] == ' ')
			{
				continue;
			}
			else if (infix[i] == '(')
			{
				obj.push(infix[i]);
			}
			else if (infix[i] >= '0' && infix[i] <= '9')
			{
				postfix[j] = infix[i];
				j++;
			}
			else if (infix[i] == '+' || infix[i] == '-' || infix[i] == '*' || infix[i] == '^' || infix[i] == '/')
			{
				while (!obj.isEmpty() && obj.Check_precedence(obj.top()) >= obj.Check_precedence(infix[i]))
				{
					postfix[j] = obj.top();
					j++;
					obj.pop();
				}
				obj.push(infix[i]);
			}
			else if (infix[i] == ')')
			{
				while (!obj.isEmpty() && obj.top() != '(')
				{
					postfix[j] = obj.top();
					j++;
					obj.pop();
				}
				obj.pop();
			}
		}
		while (!obj.isEmpty())
		{
			postfix[j] = obj.top();
			j++;
			obj.pop();
		}
		cout << " Infix To Postfix Conversion :";
		for (int i = 0; i < j; i++)
		{
			cout << postfix[i];
		}
		cout << endl;

		MyStack<int> numbers(100);
		int result = 0;
		for (int i = 0; i < size; i++)
		{
			if (postfix[i] >= '0' && postfix[i] <= '9')
			{
				numbers.push((int)postfix[i] - 48);
			}
			else
			{
				int right = numbers.pop();
				int left = numbers.pop();
				switch (postfix[i])
				{
				case '+':
				{
					result = left + right;
					break;
				}
				case '-':
				{
					result = left - right;
					break;
				}
				case '*':
				{
					result = left * right;
					break;
				}
				case '/':
				{
					result = left / right;
					break;
				}
				case '%':
				{
					result = left % right;
					break;
				}
				default:
					cout << "Error, Wrong Input !" << endl;
					exit(-1);
					break;
				}

				numbers.push(result);
			}
		}
		cout << "Aswer: " << result << endl;

		return 0;
}
    
    	