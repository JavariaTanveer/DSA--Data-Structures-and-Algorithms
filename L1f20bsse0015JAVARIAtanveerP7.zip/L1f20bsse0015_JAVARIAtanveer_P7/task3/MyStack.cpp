#include"MyStack.h"
template <class Type>
MyStack<Type>::MyStack(int size)
{
	this->size=size;
	arr = new Type[size];
	this->current=-1;
}
template <class Type>
MyStack<Type>::~MyStack()
{
	if(arr!=NULL)
	{
		delete []arr;
		arr=NULL;
	}
}
template <class Type>
bool MyStack<Type>::isFull()
{
	if(current==size-1)
	{
		return true;
	}
	return false;
}
template <class Type>
bool MyStack<Type>::isEmpty()
{
	if(current==-1)
	{
		return true;
	}
	return false;
}
template <class Type>
void MyStack<Type>::push(Type element)
{
	if(isFull())
	{
		cout<<" Stack is Already Full..."<<endl;
	}
	else
	{
		arr[current]=element;
		current++;
	}
}
template <class Type>
Type MyStack<Type>::pop()
{
	if(isEmpty())
	{
		//cout<<" Stack is Empty....Nothing to POP"<<endl;
		return -1;
	}
	else
	{
		current--;
		return arr[current];
	}
}
template <class Type>
Type MyStack<Type>::top()
{
	if(isEmpty())
	{
		//cout<<" Stack is Empty....Nothing at TOP"<<endl;
		return -1;
	}
	else
	{
		return arr[current-1];
	}
}
template<class Type>
int MyStack<Type>:: Check_precedence(char element)
{
	if (element == '+' || element == '-') 
	{
        return 1;
    }
    else if (element == '*' || element == '/') 
	{
        return 2;
    }
    else if (element == '^') 
	{
        return 3;
    }
    else 
	{
        return 0;
    }
}
template <class Type>
void MyStack<Type>::display_Stack()
{
	if(isEmpty())
	{
		cout<<"\nStack is Empty"<<endl;
	}
	else
	{
		cout<<" \nData in Stack :";
	    for(int i=0;i<current;i++)
	    {
	    	cout<<arr[i]<<" ";
		}
	}
}
