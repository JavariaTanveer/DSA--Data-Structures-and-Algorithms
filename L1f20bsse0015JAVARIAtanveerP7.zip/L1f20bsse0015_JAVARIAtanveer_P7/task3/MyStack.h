#include<iostream>
using namespace std;
template <class Type>
class MyStack
{
	private:
		Type *arr;
		int size;
		int current;
	public:
		MyStack(int size);
		~MyStack();
		bool isFull();
		bool isEmpty();
		void push(Type);
		Type pop();
		Type top();
		int Check_precedence(char);
		void display_Stack();
};
