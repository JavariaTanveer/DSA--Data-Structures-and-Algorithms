#include<iostream>
#include<string>
using namespace std;

template <class T>
class Node
{

public:
	Node()
	{
	}
	Node<T> * next;
	T data;
	Node(T data);
	void setData(T data);
	void setNext(Node<T> *  next);
	T getData();
	Node* getNext();
};

template <class T>
class LinkList
{
	Node<T> * head;
	Node<T> * tail;
public:
	static int count;
	LinkList()
	{
		head = tail = NULL;
	}
	void AddData(T data);
	bool SearchingContact(int i, string data);
	T  SearchLoginDetails(string name, string number);

	void UpdatingContact(int i, string data)
	{
		Node<T> * temp = head;
		Node<T> * prev = NULL;

		T c;
		bool flag = false;
		string name, number;

		if (i == 1)
		{
			while (temp != NULL)
			{
				c = temp->getData();
				if (c.getContactName() == data)
				{
					flag = true;
					break;
				}
				prev = temp;
				temp = temp->getNext();
			}
		}
		else
		{
			while (temp != NULL)
			{
				c = temp->getData();
				if (c.getCellNumber() == data)
				{
					flag = true;
					break;
				}
				prev = temp;
				temp = temp->getNext();
			}
		}
		if (flag)
		{
			cout << "\nContact found successfully !" << endl;
			c.DisplayContact();

			cout << "\nEnter New User Name   : ";
			getline(cin, name);
			cout << "Enter New Cell Number : ";
			getline(cin, number);
			c.setContact(name, number);

			Node<Contacts> * N = new Node<Contacts>(c);
			N->setNext(prev->getNext()->getNext());
			prev->setNext(N);
			delete temp;

			cout << "Contact updated successfully !" << endl << endl;
		}
		else
		{
			cout << "Contact doesnot exist !" << endl;
			temp = NULL;
		}
	}

	void DeleteContact(string data)
	{
		{
			Node<T> * temp = head;
			Node<T> * prev = NULL;

			T c;
			bool flag = false;

			if (head != NULL)
			{
				c = head->getData();
				if (head->getNext() == NULL && c.getCellNumber() == data)
				{
					delete head;
					head = NULL;
					cout << "Contact deleted successfully !" << endl;
					count--;
				}
				else
				{
					c = head->getData();
					if (c.getCellNumber() == data)
					{
						head = head->getNext();
						delete temp;
						cout << "Contact deleted successfully !" << endl;
						count--;
						return;
					}
					else
					{
						while (temp != NULL)
						{
							c = temp->getData();

							if (temp->getNext() == NULL && c.getCellNumber() == data)
							{
								tail = prev;
								prev->setNext(NULL);
								delete temp;
								cout << "Contact deleted successfully !" << endl;
								count--;
								return;
							}
							if (c.getCellNumber() == data)
							{
								flag = true;
								break;
							}
							prev = temp;
							temp = temp->getNext();
						}
						if (flag)
						{
							prev->setNext(temp->getNext());
							delete temp;
							cout << "Contact deleted successfully !" << endl;
							count--;
						}
						else
							cout << "Contact doesnot exist !" << endl;
					}
				}
			}
			else
				cout << "Contact list is empty !" << endl;
		}
	}
	void DisplayContacts()
	{
		if (head == NULL)
		{
			cout << "Contact List is Empty !" << endl;
		}
		else
		{
			Node<T> * temp = head;
			T c;
			cout << "-----------ContactDetial---------\n\n";
			while (temp != NULL)
			{
				c = temp->getData();
				c.DisplayContact();
				temp = temp->getNext();
			}
		}
	}
	void DisplayMessages();
};

class Contacts
{
	string contact_name;
	string cell_number;

public:
	LinkList <string> msgs;
	LinkList <string> inbox;
	LinkList <string> draft;
	LinkList <string> outbox;
	LinkList <string> history;

	Contacts()
	{
		contact_name = cell_number = " ";
	}
	void setContact(string  & name, string & number)
	{
		this->contact_name = name;
		this->cell_number = number;
	}
	string getContactName()
	{
		return contact_name;
	}
	string getCellNumber()
	{
		return cell_number;
	}
	void DisplayContact()
	{
		cout << "USER NAME  :   "; getContactName();
		cout << "CELL NUM   :   "; getCellNumber();
	}
};

class ContactList
{
	LinkList<Contacts> cont;
	Contacts c;
	int choice;
public:
	ContactList()
	{
		string name = " ", number = " ";
		choice = 0;

		while (true)
		{
			cout << "\n-------------Main Menu------------\n\n";
			cout << "1-     LOGIN     \n";
			cout << "2-     EXIT      \n\n";
			cout << "Enter  : ";
			cin >> choice;


			if (choice == 1)
				Login_Messenger(name, number);
			else
			{
				cerr << "Program exited !" << endl;
				break;
			}
		}
	}
	void Login_Messenger(string name, string number)
	{
		cin.ignore();
		cout << "\n------------LoginScreen-----------\n\n";
		cout << "USER NAME  :   ";
		cin >> name;
		cout << "CELL NUM   :   ";
		cin >> number;
		cout << endl;


		if (name == "admin" && number == "admin")
		{
			while (true)
			{
				if (AdminMenu(name, number)) {}
				else
					break;
			}
		}
		else
		{
			bool flag = false;
			int i = 0;

			c = cont.SearchLoginDetails(name, number);
			if (c.getContactName() == "" && c.getCellNumber() == "")
			{
				cout << "Contact not exist !" << endl;
			}
			else
			{
				cout << "' " << c.getContactName() << " ' has been loggined !\n------------------------------------------\n\n";
				ContactMenu();
			}

		}
	}
	bool AdminMenu(string & name, string & number)
	{
		while (true)
		{
			cout << "\n------------AdminScreen-----------\n\n";
			cout << "1-      Add contact\n";
			cout << "2-      Search contact\n";
			cout << "3-      Update contact info\n";
			cout << "4-      Delete contact\n";
			cout << "5-      Display all contacts\n";
			cout << "6-      Go back to Main Menu\n\n";
			cout << "Enter   :   ";
			cin >> choice;
			cin.ignore();

			if (choice == 1)
			{
				char x;

				cout << "\n-----------ContactDetail----------\n\n";
				cout << "Enter User Name   : ";
				getline(cin, name);
				cout << "Enter Cell Number : ";
				getline(cin, number);

				cout << "Do you want to save the contact (Y/N) : ";

				while (true)
				{
					cin >> x;
					if (x == 'Y' || x == 'N')
						break;
					else
						cout << "Enter valid option : ";
				}

				if (x == 'Y')
				{
					c.setContact(name, number);
					cont.AddData(c);
				}
				else
					cout << "Contact details discarded permanently !" << endl;
			}
			else if (choice == 2)
			{
				cout << "\n-----------ContactSearch----------\n\n";
				cout << "1-      Search by User Name\n";
				cout << "2-      Search by Cell Number\n\n";
				cout << "Enter   :   ";
				while (true)
				{
					cin >> choice;
					cin.ignore();
					if (choice == 1 || choice == 2)
					{
						if (choice == 1)
						{
							cout << "Enter User Name   : ";
							getline(cin, name);
							cont.SearchingContact(choice, name);


						}
						else
						{
							cout << "Enter Cell Number : ";
							getline(cin, number);
							cont.SearchingContact(choice, number);

						}
						cout << endl;
						break;
					}
					else
						cout << "Enter valid option : ";
				}
			}
			else if (choice == 3)
			{


				cout << "\n-----------Contact Update----------\n\n";
				cout << "1-      Search by User Name to update contact\n";
				cout << "2-      Search by Cell Number to update contact\n\n";
				cout << "Enter   :   ";

				while (true)
				{
					cin >> choice;
					cin.ignore();
					if (choice == 1 || choice == 2)
					{
						if (choice == 1)
						{
							cout << "Enter User Name   : ";
							getline(cin, name);
							cont.UpdatingContact(choice, name);
						}
						else
						{
							cout << "Enter Cell Number : ";
							getline(cin, number);
							cont.UpdatingContact(choice, number);
						}
						break;
					}
					else
						cout << "Enter valid option : ";
				}
			}
			else if (choice == 4)
			{
				cout << "\n-----------DeleteContact----------\n\n";
				cout << "Enter cell number to delete the contact : ";
				cin >> number;
				cont.DeleteContact(number);
			}
			else if (choice == 5)
			{
				cont.DisplayContacts();
			}
			else if (choice == 6)
			{
				return false;
			}
			else
				cout << "Enter valid option : ";
		}
	}
	void ContactMenu()
	{
		int choice;

		while (true)
		{

			cout << "\n------------Welcome Contact-----------\n\n";

			cout << "1-     Send message\n";
			cout << "2-     Show inbox\n";
			cout << "3-     Show Draft\n";
			cout << "4-     Show outbox\n";
			cout << "5-     Show Complete message history\n";
			cout << "6-     Go back to Main Menu\n";
			cout << "Enter  :   ";
			cin >> choice;
			cin.ignore();

			if (choice == 1)
			{
				string msg;
				bool flag = false;
				char name[100];

				cout << "Compose message to  : ";
				cin.getline(name, 100);
				int k = 0;
			}
			else if (choice == 2)
			{
				cout << "\n-------------InboxMessages------------\n\n";

			}
			else if (choice == 3)
			{
				cout << "\n-------------DraftMessages------------\n\n";
			}
			else if (choice == 4)
			{

			}
			else if (choice == 5)
			{

			}
			else if (choice == 6)
			{
				break;
			}
			else
				cout << "Enter valid option !" << endl;
		}
	}
};