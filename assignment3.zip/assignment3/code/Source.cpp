#include<iostream>
#include "Header.h"
#include<string>
using namespace std;

template<class T>
Node<T>::Node(T data)
{
	setData(data);
}

template<class T>
void Node<T>::setData(T data)
{
	this->data = data;
}

template<class T>
void Node<T>::setNext(Node<T> *next) {
	this->next = next;
}

template<class T>
T Node<T>::getData() {
	return data;
}

template<class T>
Node<T> *Node<T>::getNext() {
	return next;
}

template<class T>
void LinkList<T>::AddData(T data) {

	count++;
	Node <T> * N = new Node<T>(data);
	if (head == NULL)
	{
		head = tail = N;
	}
	else
	{
		tail->setNext(N);
		tail = tail->getNext();
	}
}

template<class T>
void LinkList<T> ::DisplayMessages(){

	if (head == NULL)
	{
		cout << "\nMessage List is Empty !" << endl << endl;
	}
	else
	{
		Node<T> * temp = head;
		while (temp != NULL)
		{
			cout << "MESSAGE : " << temp->getData() << endl;
			temp = temp->getNext();
		}
	}
	cout << endl;
}

template<class T>
bool LinkList<T>::SearchingContact(int i, string data) {

	Node<T> * temp = head;

	T c;
	bool flag = false;

	if (i == 1)
	{
		while (temp != NULL)
		{
			c = temp->getData();
			if (c.getContactName() == data)
			{
				flag = true;
				break;
			}
			temp = temp->getNext();
		}
	}
	else
	{
		while (temp != NULL)
		{
			c = temp->getData();
			if (c.getCellNumber() == data)
			{
				flag = true;
				break;
			}
			temp = temp->getNext();
		}
	}
	if (flag)
	{
		cout << "Contact with name '" << c.getContactName() << "' found !" << endl;
	}
	else
	{
		cout << "Contact doesnot exist !" << endl;
		temp = NULL;
	}
	return flag;
}

template <class T>
T  LinkList<T> ::SearchLoginDetails(string name, string number){

	Node<T> * temp = head;
	T c;
	bool flag = false;

	int i = 0, k = 0;
	while (temp != NULL)
	{
		c = temp->getData();
		if (c.getContactName() == name && c.getCellNumber() == number)
		{
			flag = true, k = i;
			break;
		}
		temp = temp->getNext(); i++;
	}

	if (flag)
	{
		cout << "Contact Found ! \n\n";
		c.DisplayContact();
		return temp->getData();
	}
	else
	{
		cout << "Contact not found in directory !" << endl;
		T a;
		return a;
	}

}