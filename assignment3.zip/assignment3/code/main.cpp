#include<iostream>
#include "Source.cpp"
#include<string>
using namespace std;
template <class T>
int LinkList<T> ::count = 0;

int main()
{
	ContactList list1;
	return 0;
}