#include "Student.h"
class LinkedList
{
private:
    Student *headStudent;
public:
    LinkedList()
    {
        headStudent = nullptr;
    }
    void setheadStudent(Student *headStudent)
    {
        this->headStudent = headStudent;
    }
    Student *getheadstudent()
    {
        return headStudent;
    }
    void push(string name, int marks)
    {
        Student *N = new Student;
        N->setname(name);
        N->setmarks(marks);
        N->setnextStudent(headStudent);
        headStudent = N;
    }
    void pop()
    {
        if (headStudent == nullptr)
        {
            cout << "List is empty" << endl;
        }
        Student *temp = headStudent;

        headStudent = headStudent->getnextStudent();
        delete temp;
    }
    void display()
    {
        if (headStudent == nullptr)
            cout << "Linked list is empty" << endl;
        else
        {
            Student *temp = headStudent;
            cout << "Name and marks are : " << endl;
            while (temp != nullptr)
            {
                cout << temp->getname() << "  " << temp->getmarks() << "  " << endl;
                temp = temp->getnextStudent();
            }
        }
    }
    void top()
    {
        cout << headStudent->getmarks();
    }
    void sorting(LinkedList &o)
    {
        LinkedList sortstack(o);
        Student *ptr = sortstack.getheadstudent();
        Student *ptr1 = ptr->getnextStudent();
        while (ptr != NULL)
        {
            while (ptr1 != NULL)
            {
                if (ptr->getmarks() < ptr1->getmarks())
                {
                    int marks;
                    string name;
                    marks = ptr->getmarks();
                    ptr->setmarks(ptr1->getmarks());
                    name = ptr->getname();
                    ptr->setname(ptr1->getname());
                    ptr1->setmarks(marks);
                    ptr1->setname(name);
                }
                ptr1 = ptr1->getnextStudent();
            }
            ptr = ptr->getnextStudent();
            ptr1 = ptr;
        }
        cout << "Top 3 positions are : "<<endl;
        int count = 0;
        Student *temp = headStudent;
        while (temp != NULL && count<3)
        {
            cout << temp->getname() << "  " << temp->getmarks() << "  " << endl;
            temp = temp->getnextStudent();
            count++;
        }
    }
};
