#include "LinkedList.h"
int main()
{
	LinkedList l;
	int choice;
	int choice2;
	do {
		cout<<"Enter 1 to add student's information "<<endl;
	    cout<<"Enter 2 to remove student's information "<<endl;
	    cout<<"Enter 3 to display student's information "<<endl;
	    cout<<"Enter 4 to dislpay 3 top positions of students "<<endl;
		cout<<"Press 5 or any other key to exit the program" << endl;
		cout<<"\nEnter Your Choice-------->";
		cin>>choice;
		while ((choice >=5))
		{
			cout<<" Exit "<<endl;
		}
		if (choice == 1)
		{
			int marks;
	        string name;
			cout << " \nEnter name and marks of student : ";
			cin>>name;
	        cin >> marks;
			l.push(name,marks);
		}
		else if (choice == 2)
		{
			l.pop();
		}
		if (choice == 3)
		{
			l.display();
		}
		else if (choice == 4)
		{
	        l.sorting(l);
		}
		cout << " \nDo You want to run the program again";
		cout << " \n Press 1 for Yes and 0 for Exit" << endl;
		cout << " \nEnter Your Choice-------->";
		cin >> choice2;
	} while (choice2 == 1);
		return 0;
}