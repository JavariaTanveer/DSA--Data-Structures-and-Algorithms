#include<iostream>
using namespace std;
class Student
{
private:
    string name;
    int marks;
    Student* nextStudent;
public:
Student()
{
    name="";
    marks=0;
    nextStudent=nullptr;
}
Student(string name, int marks)
{
    this->name=name;
    this->marks=marks;
    nextStudent=nullptr;
}
void setname(string name)
{
this->name=name;
}
string getname()
{
    return name;
}
void setmarks(int marks)
{
    this->marks=marks;
}
int getmarks()
{
    return marks;
}
void setnextStudent(Student* nextStudent)
{
  this->nextStudent=nextStudent;  
}
Student* getnextStudent()
{
return nextStudent;
}
};